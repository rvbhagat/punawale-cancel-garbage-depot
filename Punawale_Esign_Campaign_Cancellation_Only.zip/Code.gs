/******************************************************
 * PUNAWALE E-SIGN CAMPAIGN - GOOGLE APPS SCRIPT
 *
 * SETUP:
 * 1. Create a Google Sheet.
 * 2. Open Extensions > Apps Script.
 * 3. Paste this entire file into Code.gs.
 * 4. Change SHEET_ID below to your Google Sheet ID.
 * 5. Optionally change DRIVE_FOLDER_NAME.
 * 6. Run setupSheet() once and approve permissions.
 * 7. Deploy > New deployment > Web app.
 *    Execute as: Me
 *    Who has access: Anyone
 * 8. Copy the Web App URL into index.html.
 ******************************************************/

const SHEET_ID = "PASTE_YOUR_GOOGLE_SHEET_ID_HERE";
const SHEET_NAME = "Signatures";
const DRIVE_FOLDER_NAME = "Punawale E-Signatures";

function setupSheet() {
  const ss = SpreadsheetApp.openById(SHEET_ID);
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);

  if (sheet.getLastRow() === 0) {
    sheet.appendRow([
      "Timestamp",
      "Full Name",
      "Mobile",
      "Email",
      "Area / Locality",
      "Consent",
      "Signature File URL"
    ]);
    sheet.setFrozenRows(1);
    sheet.getRange(1,1,1,7).setFontWeight("bold");
  }
  return "Sheet setup complete.";
}

function getOrCreateFolder_() {
  const folders = DriveApp.getFoldersByName(DRIVE_FOLDER_NAME);
  return folders.hasNext() ? folders.next() : DriveApp.createFolder(DRIVE_FOLDER_NAME);
}

function clean_(value, max) {
  return String(value || "").trim().substring(0, max);
}

function doGet() {
  return ContentService
    .createTextOutput(JSON.stringify({ok:true, message:"Punawale e-sign campaign API is running."}))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  try {
    if (!e || !e.postData || !e.postData.contents) {
      throw new Error("No submission data received.");
    }

    const data = JSON.parse(e.postData.contents);

    const name = clean_(data.name, 100);
    const mobile = clean_(data.mobile, 20);
    const email = clean_(data.email, 150);
    const area = clean_(data.area, 120);
    const consent = data.consent === true;
    const signature = String(data.signature || "");

    if (!name || !mobile || !area || !consent || !signature.startsWith("data:image/png;base64,")) {
      throw new Error("Required information or signature is missing.");
    }

    // Basic server-side validation. Adjust if your campaign needs stricter rules.
    if (!/^[0-9+\-\s()]{7,20}$/.test(mobile)) {
      throw new Error("Please enter a valid mobile number.");
    }

    const ss = SpreadsheetApp.openById(SHEET_ID);
    let sheet = ss.getSheetByName(SHEET_NAME);
    if (!sheet) {
      setupSheet();
      sheet = ss.getSheetByName(SHEET_NAME);
    }

    const base64 = signature.split(",")[1];
    const bytes = Utilities.base64Decode(base64);
    const blob = Utilities.newBlob(bytes, "image/png", "signature_" + Date.now() + ".png");
    const file = getOrCreateFolder_().createFile(blob);

    sheet.appendRow([
      new Date(),
      name,
      mobile,
      email,
      area,
      "Yes",
      file.getUrl()
    ]);

    return ContentService
      .createTextOutput(JSON.stringify({ok:true}))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ok:false, error:String(err.message || err)}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
