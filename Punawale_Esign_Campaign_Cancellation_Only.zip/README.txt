# Punawale Garbage Depot E-Sign Campaign

This package contains:
- `index.html` — the campaign website.
- `Code.gs` — Google Apps Script backend.
- `README.txt` — setup instructions.

## 1. Create the Google Sheet

Create a blank Google Sheet. Copy the ID from its URL:

https://docs.google.com/spreadsheets/d/THIS_PART_IS_THE_SHEET_ID/edit

## 2. Configure Google Apps Script

Open the Sheet:
Extensions -> Apps Script

Replace the default Code.gs content with the supplied `Code.gs`.

Change:

SHEET_ID = "PASTE_YOUR_GOOGLE_SHEET_ID_HERE";

to your actual Sheet ID.

Save.

## 3. Initialize the sheet

In Apps Script, select `setupSheet` from the function dropdown and click Run.

Google will ask you to authorize access to Sheets and Drive. Approve it.

A tab named `Signatures` will be created with columns for timestamp, name, mobile, email, locality, consent and signature file URL.

## 4. Deploy the backend

In Apps Script:
Deploy -> New deployment -> Select type: Web app

Use:
- Execute as: Me
- Who has access: Anyone

Click Deploy and copy the Web App URL.

## 5. Connect the website

Open `index.html`.

Find:

const GOOGLE_SCRIPT_URL = "PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE";

Replace the placeholder with your Web App URL.

Save.

## 6. Publish the website

You can upload `index.html` to any static website host such as GitHub Pages, Netlify, Cloudflare Pages or your own hosting.

The Google Sheet remains the data store; Google Drive stores the signature PNG files.

## Important privacy/security notes

This campaign collects personal information and signatures. Before publishing, add a privacy notice/contact information appropriate for your campaign and only collect information that is genuinely required.

Keep the Google Sheet private. Do not publish the Sheet itself.

The current form stores the signature image in the campaign's Google Drive folder and stores the file URL in the Sheet. Anyone with access to the Sheet may be able to open those signature files depending on Drive permissions.

If this will be used for a large public campaign, consider adding:
- OTP/mobile verification
- duplicate-signature detection
- rate limiting
- CAPTCHA
- a privacy policy
- an administrator-only dashboard
